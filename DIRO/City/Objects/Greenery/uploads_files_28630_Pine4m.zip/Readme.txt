All specular maps are in the normalmaps alphachannel.
Check paths in 3ds max. The tool tends to mess up texture paths if transfered to another system.